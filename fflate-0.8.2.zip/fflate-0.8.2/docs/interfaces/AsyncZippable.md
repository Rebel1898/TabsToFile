# Interface: AsyncZippable

The complete directory structure of an asynchronously ZIPpable archive

## Indexable

▪ [path: `string`]: [`AsyncZippableFile`](../README.md#asynczippablefile)

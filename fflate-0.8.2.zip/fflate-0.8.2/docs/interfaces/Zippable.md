# Interface: Zippable

The complete directory structure of a ZIPpable archive

## Indexable

▪ [path: `string`]: [`ZippableFile`](../README.md#zippablefile)

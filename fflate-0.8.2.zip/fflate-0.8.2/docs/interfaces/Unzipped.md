# Interface: Unzipped

An unzipped archive. The full path of each file is used as the key,
and the file is the value

## Indexable

▪ [path: `string`]: `Uint8Array`

---
name: Bug
about: Report unexpected errors, corrupt files, and other bugs here
title: ''
labels: ''
assignees: ''

---

<!-- This template is just a suggestion, feel free to ignore or delete it -->
**How to reproduce**
<!-- If possible, upload files or instructions to reproduce the bug -->
<!-- You can send them to me privately at arjunbarrett@gmail.com if they contain confidential information -->

**The problem**
<!-- Mention what went wrong. More details will help me fix the issue faster -->
<!-- Even just copy-pasting an error message is enough for me to start -->

<!-- List any other context, comments, or clarifications you have here -->
